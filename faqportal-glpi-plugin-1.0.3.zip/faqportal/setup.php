<?php
/**
 * FAQ Portal connector for GLPI 11.0.11+
 * Copyright (C) 2026
 * License: GPL-3.0-or-later
 */

if (!defined('PLUGIN_FAQPORTAL_VERSION')) {
    define('PLUGIN_FAQPORTAL_VERSION', '1.0.3');
    define('PLUGIN_FAQPORTAL_MIN_GLPI', '11.0.11');
    define('PLUGIN_FAQPORTAL_MAX_GLPI', '12.0.0');
}

require_once __DIR__ . '/hook.php';

/** Initialize plugin hooks. */
function plugin_init_faqportal(): void
{
    global $PLUGIN_HOOKS;

    // Keep the native GLPI Knowledge Base disabled while the administrator's
    // reversible lockdown is active. The check also handles new/edited profiles.
    PluginFaqportalNativeKnowledgeBase::enforceIfLocked();

    $PLUGIN_HOOKS['csrf_compliant']['faqportal'] = true;
    $PLUGIN_HOOKS['display_service_catalog']['faqportal'] = [PluginFaqportalDisplay::class, 'render'];
    $PLUGIN_HOOKS['add_javascript']['faqportal'][] = 'js/faqportal.js';
    $PLUGIN_HOOKS['add_css']['faqportal'][] = 'css/faqportal.css';
    $PLUGIN_HOOKS['config_page']['faqportal'] = 'front/config.form.php';
}

/** Plugin metadata used by GLPI. */
function plugin_version_faqportal(): array
{
    return [
        'name'       => 'FAQ Portal',
        'version'    => PLUGIN_FAQPORTAL_VERSION,
        'author'     => 'FAQ Portal',
        'license'    => 'GPL-3.0-or-later',
        'homepage'   => '',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_FAQPORTAL_MIN_GLPI,
                'max' => PLUGIN_FAQPORTAL_MAX_GLPI,
            ],
        ],
    ];
}

/** Check runtime requirements before installation/activation. */
function plugin_faqportal_check_prerequisites(): bool
{
    if (!defined('GLPI_VERSION') || version_compare(GLPI_VERSION, PLUGIN_FAQPORTAL_MIN_GLPI, '<')) {
        echo 'Ce plugin requiert GLPI 11.0.11 ou une version ultérieure de GLPI 11.x.';
        return false;
    }
    if (version_compare(GLPI_VERSION, PLUGIN_FAQPORTAL_MAX_GLPI, '>=')) {
        echo 'Cette version du plugin cible GLPI 11.x. GLPI 12.x doit être validé séparément.';
        return false;
    }
    if (!function_exists('curl_init')) {
        echo 'L’extension PHP cURL est nécessaire pour contacter FAQ Portal.';
        return false;
    }
    return true;
}

/** Check plugin configuration. */
function plugin_faqportal_check_config($verbose = false): bool
{
    return true;
}

/** Install default configuration without replacing existing values. */
function plugin_faqportal_install(): bool
{
    $current = Config::getConfigurationValues('plugin:faqportal');
    $defaults = [
        'faq_base_url' => '',
        'api_token' => '',
        'max_results' => 8,
        'ticket_url' => '',
        'native_kb_lockdown' => 0,
    ];
    $to_save = [];
    foreach ($defaults as $key => $value) {
        if (!array_key_exists($key, $current)) {
            $to_save[$key] = $value;
        }
    }
    if ($to_save !== []) {
        Config::setConfigurationValues('plugin:faqportal', $to_save);
    }
    return true;
}

/** Restore native rights before removing the plugin-owned configuration. */
function plugin_faqportal_uninstall(): bool
{
    if (class_exists(PluginFaqportalNativeKnowledgeBase::class)
        && PluginFaqportalNativeKnowledgeBase::isLocked()) {
        // Never delete the backup if restoration cannot be completed.
        PluginFaqportalNativeKnowledgeBase::restore();
    }

    $config = new Config();
    $config->deleteByCriteria(['context' => 'plugin:faqportal']);
    return true;
}
