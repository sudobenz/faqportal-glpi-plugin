<?php
/** Plugin hooks and callback classes. */
require_once __DIR__ . '/inc/faqportal.class.php';
require_once __DIR__ . '/inc/native_knowledgebase.class.php';
