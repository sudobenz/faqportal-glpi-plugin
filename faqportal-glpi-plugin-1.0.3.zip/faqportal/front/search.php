<?php
/** Authenticated server-side proxy to FAQ Portal search API. */

include('../../../inc/includes.php');

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function faqportal_json_reply(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    faqportal_json_reply(405, ['error' => 'method_not_allowed']);
}

if (!Session::getLoginUserID() || Session::getCurrentInterface() !== 'helpdesk') {
    faqportal_json_reply(403, ['error' => 'forbidden']);
}

$config = Config::getConfigurationValues('plugin:faqportal');
$base_url = rtrim(trim((string) ($config['faq_base_url'] ?? '')), '/');
$api_token = trim((string) ($config['api_token'] ?? ''));
$limit = max(1, min(12, (int) ($config['max_results'] ?? 8)));
$query = preg_replace('/\s+/u', ' ', trim((string) ($_GET['q'] ?? '')));

if ($base_url === '' || $api_token === '') {
    faqportal_json_reply(503, ['error' => 'not_configured']);
}
if (!is_string($query) || mb_strlen($query) < 2) {
    faqportal_json_reply(200, ['results' => [], 'total' => 0]);
}
if (mb_strlen($query) > 120 || preg_match('/[\x00-\x1F\x7F]/', $query)) {
    faqportal_json_reply(400, ['error' => 'invalid_query']);
}

$base_parts = parse_url($base_url);
if (!is_array($base_parts) || !in_array($base_parts['scheme'] ?? '', ['http', 'https'], true) || empty($base_parts['host'])) {
    faqportal_json_reply(503, ['error' => 'invalid_faq_url']);
}
$endpoint = $base_url . '/api/integrations/glpi/v1/search?' . http_build_query([
    'q' => $query,
    'limit' => $limit,
]);

$curl = curl_init($endpoint);
curl_setopt_array($curl, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HEADER => false,
    CURLOPT_FOLLOWLOCATION => false,
    CURLOPT_CONNECTTIMEOUT => 2,
    CURLOPT_TIMEOUT => 4,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_HTTPHEADER => [
        'Accept: application/json',
        'Authorization: Bearer ' . $api_token,
    ],
]);
$response = curl_exec($curl);
$curl_error = curl_errno($curl);
$status = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);

if ($response === false || $curl_error !== 0) {
    faqportal_json_reply(502, ['error' => 'faq_unavailable']);
}
if ($status !== 200) {
    faqportal_json_reply(502, ['error' => 'faq_api_error']);
}
$data = json_decode((string) $response, true);
if (!is_array($data) || !isset($data['results']) || !is_array($data['results'])) {
    faqportal_json_reply(502, ['error' => 'invalid_faq_response']);
}

$allowed_host = strtolower((string) ($base_parts['host'] ?? ''));
$results = [];
foreach (array_slice($data['results'], 0, $limit) as $item) {
    if (!is_array($item)) {
        continue;
    }
    $title = trim(strip_tags((string) ($item['title'] ?? '')));
    $url = trim((string) ($item['url'] ?? ''));
    $url_parts = parse_url($url);
    if ($title === '' || !is_array($url_parts)
        || !in_array($url_parts['scheme'] ?? '', ['http', 'https'], true)
        || strtolower((string) ($url_parts['host'] ?? '')) !== $allowed_host) {
        continue;
    }
    $image = trim((string) ($item['image'] ?? ''));
    $image_parts = $image !== '' ? parse_url($image) : false;
    if (!is_array($image_parts)
        || !in_array($image_parts['scheme'] ?? '', ['http', 'https'], true)
        || strtolower((string) ($image_parts['host'] ?? '')) !== $allowed_host) {
        $image = '';
    }
    $results[] = [
        'title' => mb_substr($title, 0, 220),
        'summary' => mb_substr(trim(strip_tags((string) ($item['summary'] ?? ''))), 0, 300),
        'category' => mb_substr(trim(strip_tags((string) ($item['category'] ?? ''))), 0, 120),
        'url' => $url,
        'image' => $image,
    ];
}

faqportal_json_reply(200, [
    'results' => $results,
    'total' => max(0, (int) ($data['total'] ?? count($results))),
]);
