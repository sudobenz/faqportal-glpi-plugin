<?php
/** FAQ Portal connector configuration page. */

include('../../../inc/includes.php');

Session::checkRight('config', UPDATE);

$config = Config::getConfigurationValues('plugin:faqportal');
$notice = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // GLPI 11 validates and consumes the CSRF token before the plugin script runs.
    $action = (string) ($_POST['action'] ?? 'save_settings');

    try {
        if ($action === 'disable_native_kb') {
            $result = PluginFaqportalNativeKnowledgeBase::disable();
            $message = $result['already_locked']
                ? 'La base de connaissances native GLPI était déjà désactivée. Le verrouillage a été réappliqué.'
                : sprintf(
                    'Base de connaissances native GLPI désactivée pour %d profil(s), y compris les techniciens et administrateurs. Les articles et documents existants sont conservés.',
                    $result['profiles']
                );
            Session::addMessageAfterRedirect($message, true, INFO);
            Html::back();
            exit;
        }

        if ($action === 'restore_native_kb') {
            $result = PluginFaqportalNativeKnowledgeBase::restore();
            $message = sprintf(
                'Droits natifs GLPI restaurés pour %d profil(s). Les valeurs précédentes de l’accès FAQ anonyme ont été restaurées.',
                $result['restored_profiles']
            );
            Session::addMessageAfterRedirect($message, true, INFO);
            Html::back();
            exit;
        }

        if ($action !== 'save_settings') {
            throw new RuntimeException('Action de configuration inconnue.');
        }

        $faq_url = trim((string) ($_POST['faq_base_url'] ?? ''));
        $api_token = trim((string) ($_POST['api_token'] ?? ''));
        $ticket_url = trim((string) ($_POST['ticket_url'] ?? ''));
        $max_results = (int) ($_POST['max_results'] ?? 8);

        if ($faq_url !== '') {
            $parts = parse_url($faq_url);
            if (!is_array($parts) || !in_array($parts['scheme'] ?? '', ['http', 'https'], true) || empty($parts['host']) || isset($parts['query']) || isset($parts['fragment'])) {
                Session::addMessageAfterRedirect('L’URL FAQ Portal doit être une URL HTTP(S) sans paramètres ni fragment.', false, ERROR);
                Html::back();
                exit;
            }
            $faq_url = rtrim($faq_url, '/');
        }

        if ($ticket_url !== '' && !str_starts_with($ticket_url, '/')) {
            $parts = parse_url($ticket_url);
            if (!is_array($parts) || !in_array($parts['scheme'] ?? '', ['http', 'https'], true) || empty($parts['host'])) {
                Session::addMessageAfterRedirect('L’URL de destination GLPI doit être relative (commencer par /) ou HTTP(S).', false, ERROR);
                Html::back();
                exit;
            }
        }

        if ($api_token === '') {
            $api_token = (string) ($config['api_token'] ?? '');
        }

        Config::setConfigurationValues('plugin:faqportal', [
            'faq_base_url' => $faq_url,
            'api_token' => $api_token,
            'max_results' => max(1, min(12, $max_results)),
            'ticket_url' => $ticket_url,
        ]);
        Session::addMessageAfterRedirect('Configuration FAQ Portal enregistrée.', true, INFO);
        Html::back();
        exit;
    } catch (Throwable $e) {
        Session::addMessageAfterRedirect(
            'Opération FAQ Portal impossible : ' . $e->getMessage(),
            false,
            ERROR
        );
        Html::back();
        exit;
    }
}

Html::header('FAQ Portal', $_SERVER['PHP_SELF'], 'config', 'plugins');

$config = Config::getConfigurationValues('plugin:faqportal');
$faq_url = htmlspecialchars((string) ($config['faq_base_url'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$ticket_url = htmlspecialchars((string) ($config['ticket_url'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$max_results = max(1, min(12, (int) ($config['max_results'] ?? 8)));
$token_configured = !empty($config['api_token']);
$native_kb_locked = PluginFaqportalNativeKnowledgeBase::isLocked();
$profiles_count = 0;
if ($native_kb_locked) {
    $profiles_count = PluginFaqportalNativeKnowledgeBase::countProfiles();
}

// Connector settings.
echo '<div class="container mt-4" style="max-width:900px">';
echo '<h2>Intégration FAQ Portal</h2>';
echo '<p>Les articles sont fournis par FAQ Portal. Les formulaires natifs GLPI restent inchangés.</p>';
echo '<form method="post">';
echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
echo '<input type="hidden" name="action" value="save_settings">';
echo '<div class="mb-3"><label class="form-label" for="faq_base_url">URL de FAQ Portal</label>';
echo '<input class="form-control" type="url" id="faq_base_url" name="faq_base_url" required value="' . $faq_url . '" placeholder="https://faq.example.com">';
echo '<small class="form-text">URL publique de base du portail, sans / final.</small></div>';
echo '<div class="mb-3"><label class="form-label" for="api_token">Clé API</label>';
echo '<input class="form-control" type="password" id="api_token" name="api_token" autocomplete="new-password" value="" placeholder="' . ($token_configured ? 'Clé déjà enregistrée — laisser vide pour la conserver' : 'Coller la clé générée dans FAQ Portal') . '">';
echo '<small class="form-text">Stockée côté serveur dans la configuration GLPI. Jamais envoyée au navigateur.</small></div>';
echo '<div class="mb-3"><label class="form-label" for="max_results">Nombre maximal de résultats</label>';
echo '<input class="form-control" type="number" id="max_results" name="max_results" min="1" max="12" value="' . $max_results . '"></div>';
echo '<div class="mb-3"><label class="form-label" for="ticket_url">Destination du bouton de création de demande</label>';
echo '<input class="form-control" type="text" id="ticket_url" name="ticket_url" value="' . $ticket_url . '" placeholder="/ServiceCatalog">';
echo '<small class="form-text">Par défaut : /ServiceCatalog. Vous pouvez indiquer l’URL d’un formulaire GLPI natif si nécessaire.</small></div>';
echo '<button type="submit" class="btn btn-primary" name="update" value="1">Enregistrer la configuration</button>';
echo '</form>';

// Native GLPI KB management.
echo '<hr class="my-4">';
echo '<h3>Base de connaissances native GLPI</h3>';
echo '<p>Cette option désactive la fonctionnalité native de base de connaissances pour tous les profils GLPI, y compris Self-Service, techniciens, administrateurs et Super-Admin. Elle ne supprime aucun article, document, commentaire ou historique.</p>';

if ($native_kb_locked) {
    echo '<div class="alert alert-warning" role="status">';
    echo '<strong>Base de connaissances native désactivée.</strong><br>';
    echo 'Verrouillage actif sur ' . (int) $profiles_count . ' profil(s). Les droits sont contrôlés à chaque requête : les profils créés ou modifiés ultérieurement sont également privés des droits de base de connaissances.';
    echo '</div>';
    echo '<p>Les droits des profils et le paramètre d’accès FAQ anonyme sont sauvegardés par le plugin. La restauration rétablit ces valeurs sans supprimer le contenu GLPI.</p>';
    echo '<form method="post" onsubmit="return confirm(\'Réactiver la base de connaissances native GLPI et restaurer les droits enregistrés ?\');">';
    echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
    echo '<input type="hidden" name="action" value="restore_native_kb">';
    echo '<button type="submit" class="btn btn-outline-secondary">Restaurer les droits et réactiver la base native</button>';
    echo '</form>';
} else {
    echo '<div class="alert alert-info" role="note">';
    echo '<strong>Base de connaissances native actuellement sous le contrôle des droits GLPI.</strong><br>';
    echo 'La désactivation retirera toutes les permissions du module <code>knowbase</code> sur chaque profil et désactivera également l’accès FAQ anonyme.';
    echo '</div>';
    echo '<p><strong>Conséquence :</strong> les techniciens ne pourront plus lire, créer, publier, commenter ou administrer les articles natifs GLPI. Ils devront utiliser l’outil documentaire externe prévu. Les autres fonctions GLPI, notamment tickets, formulaires et catalogue de services, ne sont pas modifiées.</p>';
    echo '<form method="post" onsubmit="return confirm(\'Confirmer la désactivation de la base de connaissances native GLPI pour TOUS les profils, y compris techniciens, administrateurs et Super-Admin ? Une sauvegarde des droits actuels sera créée et une restauration restera possible depuis cette page.\');">';
    echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
    echo '<input type="hidden" name="action" value="disable_native_kb">';
    echo '<button type="submit" class="btn btn-danger">Désactiver la base de connaissances native pour tous les profils</button>';
    echo '</form>';
}

echo '</div>';

Html::footer();
