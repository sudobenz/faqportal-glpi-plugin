<?php
/**
 * Reversible native GLPI knowledge-base lockdown.
 * Compatible with GLPI 11.0.11+ (11.x).
 *
 * This class only changes ProfileRight records through GLPI's own API and
 * the core `use_public_faq` configuration value. It never deletes KB content.
 */

class PluginFaqportalNativeKnowledgeBase
{
    private const CONFIG_CONTEXT = 'plugin:faqportal';
    private const LOCK_KEY = 'native_kb_lockdown';
    private const SNAPSHOT_KEY = 'native_kb_snapshot';
    private const RIGHT_NAME = 'knowbase';

    /** Return whether the native knowledge base lockdown is enabled. */
    public static function isLocked(): bool
    {
        return (string) Config::getConfigurationValue(self::CONFIG_CONTEXT, self::LOCK_KEY) === '1';
    }

    /**
     * Save current rights, then disable every knowledge-base right on every
     * existing profile and disable anonymous FAQ access.
     *
     * @return array{profiles:int,public_faq_was_enabled:bool,already_locked:bool}
     */
    public static function disable(): array
    {
        global $DB;

        if (self::isLocked()) {
            self::enforce();
            return [
                'profiles' => self::countProfiles(),
                'public_faq_was_enabled' => false,
                'already_locked' => true,
            ];
        }

        $profiles_snapshot = [];
        $iterator = $DB->request([
            'SELECT' => ['id', 'name'],
            'FROM'   => Profile::getTable(),
            'ORDER'  => 'id ASC',
        ]);

        foreach ($iterator as $profile) {
            $profile_id = (int) $profile['id'];
            $rights = ProfileRight::getProfileRights($profile_id, [self::RIGHT_NAME]);
            $profiles_snapshot[(string) $profile_id] = [
                'name' => (string) $profile['name'],
                // NULL means there was no explicit row. It is restored as 0,
                // which preserves the effective permission (no access).
                'rights' => array_key_exists(self::RIGHT_NAME, $rights)
                    ? (int) $rights[self::RIGHT_NAME]
                    : null,
            ];
        }

        global $CFG_GLPI;
        $public_faq = Config::getConfigurationValue('core', 'use_public_faq');
        $snapshot = [
            'version' => 1,
            'created_at' => date(DATE_ATOM),
            'use_public_faq' => $public_faq === null ? null : (string) $public_faq,
            'use_public_faq_effective' => !empty($CFG_GLPI['use_public_faq']),
            'profiles' => $profiles_snapshot,
        ];

        $encoded_snapshot = json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($encoded_snapshot)) {
            throw new RuntimeException('Impossible de sérialiser la sauvegarde des droits GLPI.');
        }

        // Persist snapshot and active state BEFORE changing rights. If a later
        // update is interrupted, enforce() completes the lockdown next request.
        Config::setConfigurationValues(self::CONFIG_CONTEXT, [
            self::SNAPSHOT_KEY => $encoded_snapshot,
            self::LOCK_KEY => 1,
        ]);

        self::enforce();

        return [
            'profiles' => count($profiles_snapshot),
            'public_faq_was_enabled' => in_array(strtolower((string) $public_faq), ['1', 'true', 'yes'], true),
            'already_locked' => false,
        ];
    }

    /**
     * Restore the rights recorded before the lockdown.
     * Profiles created during the lockdown are deliberately left without KB
     * rights because no former permission value exists for them.
     *
     * @return array{restored_profiles:int,public_faq_restored:bool}
     */
    public static function restore(): array
    {
        global $CFG_GLPI;

        $raw_snapshot = Config::getConfigurationValue(self::CONFIG_CONTEXT, self::SNAPSHOT_KEY);
        if (!is_string($raw_snapshot) || $raw_snapshot === '') {
            throw new RuntimeException('Aucune sauvegarde des droits natifs GLPI n’est disponible. Restauration annulée.');
        }

        $snapshot = json_decode($raw_snapshot, true);
        if (!is_array($snapshot) || !isset($snapshot['profiles']) || !is_array($snapshot['profiles'])) {
            throw new RuntimeException('La sauvegarde des droits est invalide. Aucune restauration effectuée.');
        }

        // Keep the lockdown active until all saved profile rights have been
        // restored successfully. On failure, the next request re-applies it.
        $restored = 0;
        foreach ($snapshot['profiles'] as $profile_id_string => $data) {
            $profile_id = (int) $profile_id_string;
            if ($profile_id <= 0) {
                continue;
            }
            $profile = new Profile();
            if (!$profile->getFromDB($profile_id)) {
                continue; // The profile was removed since the snapshot.
            }

            $saved_right = null;
            if (is_array($data) && array_key_exists('rights', $data)) {
                $saved_right = $data['rights'];
            }
            $rights_value = $saved_right === null ? 0 : (int) $saved_right;
            ProfileRight::updateProfileRights($profile_id, [self::RIGHT_NAME => $rights_value]);
            $restored++;
        }

        $public_faq = $snapshot['use_public_faq'] ?? null;
        if ($public_faq === null) {
            Config::deleteConfigurationValues('core', ['use_public_faq']);
            $public_faq_restored = false;
            // Restore the effective default while leaving the original DB
            // configuration row absent, exactly as it was before the lock.
            $CFG_GLPI['use_public_faq'] = !empty($snapshot['use_public_faq_effective']);
        } else {
            $public_faq_value = (string) $public_faq;
            Config::setConfigurationValues('core', ['use_public_faq' => $public_faq_value]);
            $CFG_GLPI['use_public_faq'] = $public_faq_value;
            $public_faq_restored = true;
        }

        // Disable enforcement only after the rights and public option are restored.
        Config::setConfigurationValues(self::CONFIG_CONTEXT, [self::LOCK_KEY => 0]);
        Config::deleteConfigurationValues(self::CONFIG_CONTEXT, [self::SNAPSHOT_KEY]);

        if (isset($_SESSION['glpiactiveprofile']['id'])) {
            $active_profile_id = (string) $_SESSION['glpiactiveprofile']['id'];
            if (isset($snapshot['profiles'][$active_profile_id]['rights'])) {
                $active_right = $snapshot['profiles'][$active_profile_id]['rights'];
                $_SESSION['glpiactiveprofile'][self::RIGHT_NAME] = $active_right === null ? 0 : (int) $active_right;
            }
        }

        return [
            'restored_profiles' => $restored,
            'public_faq_restored' => $public_faq_restored,
        ];
    }

    /**
     * Enforce the lockdown on every request while enabled. This also catches
     * profiles created or edited after the initial operation.
     */
    public static function enforceIfLocked(): void
    {
        if (self::isLocked()) {
            self::enforce();
        }
    }

    /** Apply zero rights to any profile currently holding a KB permission. */
    private static function enforce(): void
    {
        global $DB, $CFG_GLPI;

        $iterator = $DB->request([
            'SELECT' => ['profiles_id'],
            'FROM'   => ProfileRight::getTable(),
            'WHERE'  => [
                'name' => self::RIGHT_NAME,
                'rights' => ['<>', 0],
            ],
        ]);

        foreach ($iterator as $right_row) {
            ProfileRight::updateProfileRights((int) $right_row['profiles_id'], [self::RIGHT_NAME => 0]);
        }

        // Refresh the current request's active rights immediately. Other
        // sessions are corrected on their next request by this same method.
        if (isset($_SESSION['glpiactiveprofile']) && is_array($_SESSION['glpiactiveprofile'])) {
            $_SESSION['glpiactiveprofile'][self::RIGHT_NAME] = 0;
        }

        // Anonymous access bypasses profile rights in GLPI's checkFaqAccess().
        // It must therefore be disabled separately.
        if (!empty($CFG_GLPI['use_public_faq'])) {
            Config::setConfigurationValues('core', ['use_public_faq' => 0]);
        }
        $CFG_GLPI['use_public_faq'] = 0;
    }

    public static function countProfiles(): int
    {
        global $DB;
        $row = $DB->request(['COUNT' => 'cpt', 'FROM' => Profile::getTable()])->current();
        return (int) ($row['cpt'] ?? 0);
    }
}
