<?php
/** Rendering helpers for the FAQ Portal GLPI integration. */

class PluginFaqportalDisplay
{
    /** Render an independent FAQ result panel below the native catalog search. */
    public static function render(): void
    {
        global $CFG_GLPI;

        if (!Session::getLoginUserID() || Session::getCurrentInterface() !== 'helpdesk') {
            return;
        }

        $config = Config::getConfigurationValues('plugin:faqportal');
        $root_doc = rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/');
        $endpoint = $root_doc . '/plugins/faqportal/front/search.php';
        $ticket_url = trim((string) ($config['ticket_url'] ?? ''));
        if ($ticket_url === '') {
            $ticket_url = $root_doc . '/ServiceCatalog';
        } elseif (str_starts_with($ticket_url, '/') && !str_starts_with($ticket_url, '//')) {
            $ticket_url = $root_doc . $ticket_url;
        }

        $configured = !empty($config['faq_base_url']) && !empty($config['api_token']);
        $safe_endpoint = htmlspecialchars($endpoint, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $safe_ticket = htmlspecialchars($ticket_url, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $status = $configured
            ? 'Saisissez au moins deux caractères dans la recherche ci-dessus pour consulter les articles FAQ.'
            : 'Le connecteur FAQ Portal doit être configuré par un administrateur GLPI.';

        echo '<section id="faqportal-panel" class="faqportal-panel"'
            . ' data-endpoint="' . $safe_endpoint . '"'
            . ' data-ticket-url="' . $safe_ticket . '"'
            . ' data-configured="' . ($configured ? '1' : '0') . '"'
            . ' aria-labelledby="faqportal-title">';
        echo '<div class="faqportal-panel__header">';
        echo '<div><span class="faqportal-eyebrow">CENTRE D’AIDE</span>';
        echo '<h2 id="faqportal-title">Articles FAQ Portal</h2>';
        echo '<p>Des réponses et procédures avant d’ouvrir une demande au support.</p></div>';
        echo '<span class="faqportal-panel__source">FAQ indépendante</span>';
        echo '</div>';
        echo '<div id="faqportal-status" class="faqportal-status" role="status" aria-live="polite">'
            . htmlspecialchars($status, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</div>';
        echo '<div id="faqportal-results" class="faqportal-results" aria-live="polite"></div>';
        echo '<div class="faqportal-panel__footer">';
        echo '<span>Vous n’avez pas trouvé la solution ?</span>';
        echo '<a class="btn btn-primary" href="' . $safe_ticket . '">Accéder aux formulaires GLPI</a>';
        echo '</div>';
        echo '</section>';
    }
}
