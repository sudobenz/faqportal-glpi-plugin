(function () {
    'use strict';

    const SEARCH_MIN_LENGTH = 2;
    const SEARCH_DEBOUNCE_MS = 450;

    function normalizeQuery(value) {
        return String(value || '').trim().replace(/\s+/g, ' ');
    }

    function safeExternalUrl(value) {
        try {
            const parsed = new URL(value, window.location.href);
            if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return '';
            return parsed.href;
        } catch (_error) {
            return '';
        }
    }

    function getSearchEndpoint() {
        // CFG_GLPI.root_doc is the same GLPI runtime setting used by the native
        // Helpdesk search controller. It also supports installations in a subfolder.
        const rootDoc = (typeof CFG_GLPI !== 'undefined' && CFG_GLPI.root_doc)
            ? String(CFG_GLPI.root_doc).replace(/\/$/, '')
            : '';
        return `${rootDoc}/plugins/faqportal/front/search.php`;
    }

    async function fetchFaqResults(endpoint, query, signal) {
        const url = new URL(endpoint, window.location.href);
        url.searchParams.set('q', query);
        const response = await fetch(url.href, {
            method: 'GET',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' },
            signal,
        });
        if (!response.ok) {
            throw new Error(`FAQ Portal search failed: HTTP ${response.status}`);
        }
        const payload = await response.json();
        return {
            results: Array.isArray(payload.results) ? payload.results : [],
            total: Number(payload.total || 0),
        };
    }

    function createResultCard(item, compact) {
        const url = safeExternalUrl(item.url);
        if (!url || !item.title) return null;

        const card = document.createElement('article');
        card.className = compact
            ? 'faqportal-home-result'
            : 'faqportal-result';

        if (item.image) {
            const imageUrl = safeExternalUrl(item.image);
            if (imageUrl) {
                const image = document.createElement('img');
                image.className = compact
                    ? 'faqportal-home-result__image'
                    : 'faqportal-result__image';
                image.src = imageUrl;
                image.alt = '';
                image.loading = 'lazy';
                card.appendChild(image);
            }
        }

        const body = document.createElement('div');
        body.className = compact
            ? 'faqportal-home-result__body'
            : 'faqportal-result__body';

        const heading = document.createElement('a');
        heading.className = compact
            ? 'faqportal-home-result__title'
            : 'faqportal-result__title';
        heading.href = url;
        heading.target = '_blank';
        heading.rel = 'noopener noreferrer';
        heading.textContent = item.title;
        body.appendChild(heading);

        if (item.summary) {
            const summary = document.createElement('p');
            summary.className = compact
                ? 'faqportal-home-result__summary'
                : 'faqportal-result__summary';
            summary.textContent = item.summary;
            body.appendChild(summary);
        }

        if (item.category) {
            const category = document.createElement('span');
            category.className = compact
                ? 'faqportal-home-result__category'
                : 'faqportal-result__category';
            category.textContent = item.category;
            body.appendChild(category);
        }

        card.appendChild(body);
        return card;
    }

    /** Existing integration: independent panel below the Service Catalog search. */
    function initCatalogSearch() {
        const panel = document.getElementById('faqportal-panel');
        const searchInput = document.querySelector('[data-glpi-service-catalog-filter-items]');
        if (!panel || !searchInput) return;

        const status = document.getElementById('faqportal-status');
        const results = document.getElementById('faqportal-results');
        if (!status || !results) return;

        const endpoint = panel.dataset.endpoint || getSearchEndpoint();
        const configured = panel.dataset.configured === '1';
        let timer = null;
        let controller = null;
        let lastQuery = '';

        function setStatus(message, kind) {
            status.textContent = message;
            status.classList.toggle('is-error', kind === 'error');
            status.classList.toggle('is-loading', kind === 'loading');
        }

        function clearResults() {
            results.replaceChildren();
        }

        function renderResults(items, total) {
            clearResults();
            const fragment = document.createDocumentFragment();
            items.forEach((item) => {
                const card = createResultCard(item, false);
                if (card) fragment.appendChild(card);
            });
            results.appendChild(fragment);

            if (!items.length) {
                setStatus('Aucun article FAQ correspondant. Les formulaires GLPI restent disponibles ci-dessous.', '');
                return;
            }
            const suffix = total > items.length ? ` — ${total} résultat(s) au total` : '';
            setStatus(`${results.children.length} article(s) FAQ trouvé(s)${suffix}.`, '');
        }

        async function search(query) {
            if (!configured) return;
            if (controller) controller.abort();
            controller = new AbortController();
            setStatus('Recherche dans FAQ Portal…', 'loading');
            clearResults();
            try {
                const payload = await fetchFaqResults(endpoint, query, controller.signal);
                renderResults(payload.results, payload.total);
            } catch (error) {
                if (error.name === 'AbortError') return;
                clearResults();
                setStatus('FAQ Portal est momentanément indisponible. Les formulaires GLPI restent opérationnels.', 'error');
            }
        }

        searchInput.addEventListener('input', function () {
            const query = normalizeQuery(searchInput.value);
            if (query === lastQuery) return;
            lastQuery = query;
            window.clearTimeout(timer);
            if (query.length < SEARCH_MIN_LENGTH) {
                if (controller) controller.abort();
                clearResults();
                setStatus('Saisissez au moins deux caractères pour rechercher dans FAQ Portal.', '');
                return;
            }
            timer = window.setTimeout(() => search(query), 350);
        });

        const initialQuery = normalizeQuery(searchInput.value);
        if (initialQuery.length >= SEARCH_MIN_LENGTH) {
            lastQuery = initialQuery;
            search(initialQuery);
        }
    }

    /**
     * Add FAQ Portal results to GLPI's native Self-Service home search dropdown.
     * GLPI's Helpdesk controller replaces #search-results.innerHTML after every
     * native search. A direct append would therefore be lost. A MutationObserver
     * restores the FAQ section after each native response without changing the
     * native result markup or its event handlers.
     */
    function initHomeSearch() {
        const searchInput = document.querySelector('#search-input');
        const nativeResults = document.querySelector('#search-results');
        if (!searchInput || !nativeResults) return;

        const endpoint = getSearchEndpoint();
        let timer = null;
        let controller = null;
        let lastQuery = '';
        let lastPayload = null;
        let currentStatus = 'Saisissez au moins deux caractères pour rechercher dans FAQ Portal.';
        let statusKind = '';

        function buildPanel() {
            const panel = document.createElement('section');
            panel.id = 'faqportal-home-panel';
            panel.className = 'faqportal-home-panel';
            panel.setAttribute('aria-label', 'Articles FAQ Portal');

            const header = document.createElement('div');
            header.className = 'faqportal-home-panel__header';
            const title = document.createElement('span');
            title.className = 'faqportal-home-panel__title';
            title.textContent = 'ARTICLES FAQ PORTAL';
            const status = document.createElement('span');
            status.className = 'faqportal-home-panel__status';
            status.setAttribute('role', 'status');
            status.setAttribute('aria-live', 'polite');
            header.append(title, status);

            const results = document.createElement('div');
            results.className = 'faqportal-home-panel__results';
            panel.append(header, results);
            return panel;
        }

        function ensurePanel() {
            let panel = nativeResults.querySelector('#faqportal-home-panel');
            if (!panel) {
                panel = buildPanel();
                nativeResults.appendChild(panel);
            }
            return panel;
        }

        function renderPayload(payload) {
            const panel = ensurePanel();
            const status = panel.querySelector('.faqportal-home-panel__status');
            const results = panel.querySelector('.faqportal-home-panel__results');
            results.replaceChildren();

            if (!payload.results.length) {
                status.textContent = 'Aucun article FAQ correspondant.';
                panel.classList.remove('is-loading', 'is-error');
                return;
            }

            const fragment = document.createDocumentFragment();
            payload.results.forEach((item) => {
                const card = createResultCard(item, true);
                if (card) fragment.appendChild(card);
            });
            results.appendChild(fragment);
            const suffix = payload.total > results.children.length
                ? ` — ${payload.total} résultat(s) au total`
                : '';
            status.textContent = `${results.children.length} article(s) trouvé(s)${suffix}`;
            panel.classList.remove('is-loading', 'is-error');
        }

        function renderStatus() {
            const panel = ensurePanel();
            const status = panel.querySelector('.faqportal-home-panel__status');
            status.textContent = currentStatus;
            panel.classList.toggle('is-loading', statusKind === 'loading');
            panel.classList.toggle('is-error', statusKind === 'error');
        }

        function clearPanel() {
            const panel = nativeResults.querySelector('#faqportal-home-panel');
            if (panel) panel.remove();
            lastPayload = null;
        }

        async function search(query) {
            if (controller) controller.abort();
            controller = new AbortController();
            currentStatus = 'Recherche dans FAQ Portal…';
            statusKind = 'loading';
            renderStatus();
            try {
                const payload = await fetchFaqResults(endpoint, query, controller.signal);
                if (query !== lastQuery) return;
                lastPayload = payload;
                statusKind = '';
                renderPayload(payload);
            } catch (error) {
                if (error.name === 'AbortError') return;
                currentStatus = 'FAQ Portal est momentanément indisponible.';
                statusKind = 'error';
                lastPayload = null;
                renderStatus();
            }
        }

        const observer = new MutationObserver(() => {
            if (lastQuery.length < SEARCH_MIN_LENGTH) return;
            const panel = nativeResults.querySelector('#faqportal-home-panel');
            if (!panel) {
                if (lastPayload) {
                    renderPayload(lastPayload);
                } else {
                    renderStatus();
                }
            }
        });
        observer.observe(nativeResults, { childList: true });

        searchInput.addEventListener('input', function () {
            const query = normalizeQuery(searchInput.value);
            if (query === lastQuery) return;
            lastQuery = query;
            window.clearTimeout(timer);

            if (query.length < SEARCH_MIN_LENGTH) {
                if (controller) controller.abort();
                clearPanel();
                currentStatus = 'Saisissez au moins deux caractères pour rechercher dans FAQ Portal.';
                statusKind = '';
                return;
            }

            lastPayload = null;
            currentStatus = 'Recherche dans FAQ Portal…';
            statusKind = 'loading';
            renderStatus();
            timer = window.setTimeout(() => search(query), SEARCH_DEBOUNCE_MS);
        });

        // If GLPI has already populated the search field (e.g. browser restore),
        // include FAQ Portal results for the same initial query.
        const initialQuery = normalizeQuery(searchInput.value);
        if (initialQuery.length >= SEARCH_MIN_LENGTH) {
            lastQuery = initialQuery;
            timer = window.setTimeout(() => search(initialQuery), SEARCH_DEBOUNCE_MS);
        }
    }

    function init() {
        initCatalogSearch();
        initHomeSearch();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
        init();
    }
})();
