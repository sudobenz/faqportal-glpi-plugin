# FAQ Portal GLPI — version 1.0.3

## Correction : résultats FAQ dans la recherche de l’accueil Self-Service

La version 1.0.3 complète l’intégration du Catalogue de services en ajoutant les articles FAQ Portal à la liste déroulante de la recherche instantanée de l’accueil GLPI 11.

Sur GLPI 11.0.11, le template `templates/pages/helpdesk/index.html.twig` expose `#search-input` et `#search-results`. Le contrôleur natif remplace le contenu de `#search-results` après chaque réponse à `/Helpdesk/Search`. Le plugin observe les changements des enfants directs de cette zone et ajoute une section distincte « ARTICLES FAQ PORTAL ».

Le plugin ne remplace pas les résultats natifs et ne modifie pas le JavaScript du cœur GLPI. Les résultats des formulaires restent gérés par GLPI. La recherche FAQ passe par le relais PHP déjà utilisé par le Catalogue de services, avec clé API conservée côté serveur.

Le fonctionnement du Catalogue de services est conservé. La désactivation réversible de la base de connaissances native ajoutée en 1.0.2 est également conservée.

## Mise à jour

1. Sauvegarder le répertoire `plugins/faqportal`.
2. Remplacer uniquement ce répertoire par celui de l’archive 1.0.3.
3. Ne pas désinstaller le plugin : cela déclencherait la restauration des droits natifs.
4. Vérifier que le répertoire installé est bien `plugins/faqportal/` et que `public/js/faqportal.js` contient le code 1.0.3.
5. Recharger GLPI avec `Ctrl+F5`.
6. Tester une recherche dans l’accueil Self-Service, puis dans le Catalogue de services.

## Contrôles réalisés

- `php -l` sur tous les fichiers PHP du plugin.
- `node --check` sur `public/js/faqportal.js`.
- Contrôles statiques des identifiants natifs GLPI relevés sur l’instance cible : `#search-input` et `#search-results`.
- Vérification que la recherche native conserve son HTML et que la section FAQ est ajoutée comme enfant distinct.

Un test navigateur réel sur l’instance de production n’a pas été effectué depuis cet environnement.
